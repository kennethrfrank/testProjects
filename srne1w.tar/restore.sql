--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 10.0
-- Dumped by pg_dump version 10.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.posts DROP CONSTRAINT post_accountid_fk;
ALTER TABLE ONLY public.outboxes DROP CONSTRAINT outbox_senderid_fk;
ALTER TABLE ONLY public.nclynations DROP CONSTRAINT nclynation_accountid_fk;
ALTER TABLE ONLY public.likes DROP CONSTRAINT liker_accountid_fk;
ALTER TABLE ONLY public.likes DROP CONSTRAINT like_accountid_fk;
ALTER TABLE ONLY public.inboxes DROP CONSTRAINT inbox_receiverid_fk;
ALTER TABLE ONLY public.files DROP CONSTRAINT file_accountid_fk;
ALTER TABLE ONLY public.details DROP CONSTRAINT detail_accountid_fk;
ALTER TABLE ONLY public.comments DROP CONSTRAINT comment_accountid_fk;
ALTER TABLE ONLY public.talents DROP CONSTRAINT talent_pk;
ALTER TABLE ONLY public.posts DROP CONSTRAINT posts_id_pk;
ALTER TABLE ONLY public.outboxes DROP CONSTRAINT outboxes_id_pk;
ALTER TABLE ONLY public.nclynations DROP CONSTRAINT nclynations_id_pk;
ALTER TABLE ONLY public.likes DROP CONSTRAINT likes_id_pk;
ALTER TABLE ONLY public.inboxes DROP CONSTRAINT inboxes_id_pk;
ALTER TABLE ONLY public.files DROP CONSTRAINT files_id_pk;
ALTER TABLE ONLY public.details DROP CONSTRAINT details_id_pk;
ALTER TABLE ONLY public.comments DROP CONSTRAINT comment_id_pk;
ALTER TABLE ONLY public.acctalents DROP CONSTRAINT acctalents_id_pk;
ALTER TABLE ONLY public.accounts DROP CONSTRAINT account_id_pk;
ALTER TABLE public.usersfolloweds ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.talents ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.posts ALTER COLUMN postid DROP DEFAULT;
ALTER TABLE public.outboxes ALTER COLUMN outboxid DROP DEFAULT;
ALTER TABLE public.nclynations ALTER COLUMN nclynationid DROP DEFAULT;
ALTER TABLE public.nclynationaccordions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.likes ALTER COLUMN likeid DROP DEFAULT;
ALTER TABLE public.inboxes ALTER COLUMN inboxid DROP DEFAULT;
ALTER TABLE public.files ALTER COLUMN fileid DROP DEFAULT;
ALTER TABLE public.embededs ALTER COLUMN embededid DROP DEFAULT;
ALTER TABLE public.details ALTER COLUMN detailsid DROP DEFAULT;
ALTER TABLE public.comments ALTER COLUMN commentid DROP DEFAULT;
ALTER TABLE public.acctalents ALTER COLUMN talentid DROP DEFAULT;
ALTER TABLE public.accounts ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE public.usersfolloweds_id_seq;
DROP TABLE public.usersfolloweds;
DROP SEQUENCE public.talents_id_seq;
DROP TABLE public.talents;
DROP SEQUENCE public.posts_postid_seq;
DROP TABLE public.posts;
DROP SEQUENCE public.outboxes_outboxid_seq;
DROP TABLE public.outboxes;
DROP SEQUENCE public.nclynations_nclynationid_seq;
DROP TABLE public.nclynations;
DROP SEQUENCE public.nclynationaccordions_id_seq;
DROP TABLE public.nclynationaccordions;
DROP SEQUENCE public.likes_likeid_seq;
DROP TABLE public.likes;
DROP SEQUENCE public.inboxes_inboxid_seq;
DROP TABLE public.inboxes;
DROP SEQUENCE public.files_fileid_seq;
DROP TABLE public.files;
DROP SEQUENCE public.embededs_embededid_seq;
DROP TABLE public.embededs;
DROP SEQUENCE public.details_detailsid_seq;
DROP TABLE public.details;
DROP SEQUENCE public.comments_commentid_seq;
DROP TABLE public.comments;
DROP SEQUENCE public.acctalents_talentid_seq;
DROP TABLE public.acctalents;
DROP SEQUENCE public.accounts_id_seq;
DROP TABLE public.accounts;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: accounts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE accounts (
    id integer NOT NULL,
    username character varying(20),
    accountrole character varying(3000),
    accpassword character varying(20),
    useremail character varying(3000),
    remember bit(1),
    likes integer
);


ALTER TABLE accounts OWNER TO postgres;

--
-- Name: accounts_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE accounts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE accounts_id_seq OWNER TO postgres;

--
-- Name: accounts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE accounts_id_seq OWNED BY accounts.id;


--
-- Name: acctalents; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE acctalents (
    talentid integer NOT NULL,
    talentname character varying(30),
    nclynationid integer
);


ALTER TABLE acctalents OWNER TO postgres;

--
-- Name: acctalents_talentid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE acctalents_talentid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE acctalents_talentid_seq OWNER TO postgres;

--
-- Name: acctalents_talentid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE acctalents_talentid_seq OWNED BY acctalents.talentid;


--
-- Name: comments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE comments (
    commentid integer NOT NULL,
    accountid integer,
    comment1 character varying(250),
    sender character varying(20),
    senderid integer,
    datesent timestamp without time zone
);


ALTER TABLE comments OWNER TO postgres;

--
-- Name: comments_commentid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE comments_commentid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE comments_commentid_seq OWNER TO postgres;

--
-- Name: comments_commentid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE comments_commentid_seq OWNED BY comments.commentid;


--
-- Name: details; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE details (
    hook character varying(300),
    accountid integer,
    nclynation character varying(20),
    detailsid integer NOT NULL
);


ALTER TABLE details OWNER TO postgres;

--
-- Name: details_detailsid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE details_detailsid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE details_detailsid_seq OWNER TO postgres;

--
-- Name: details_detailsid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE details_detailsid_seq OWNED BY details.detailsid;


--
-- Name: embededs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE embededs (
    nclynationid integer,
    src character varying(3000),
    framefrom character varying(20),
    frametype character varying(25),
    embededid integer NOT NULL
);


ALTER TABLE embededs OWNER TO postgres;

--
-- Name: embededs_embededid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE embededs_embededid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE embededs_embededid_seq OWNER TO postgres;

--
-- Name: embededs_embededid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE embededs_embededid_seq OWNED BY embededs.embededid;


--
-- Name: files; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE files (
    filename character varying(3000),
    contenttype character varying(3000),
    content bytea,
    filetype character varying(3000),
    accountid integer,
    fileid integer NOT NULL
);


ALTER TABLE files OWNER TO postgres;

--
-- Name: files_fileid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE files_fileid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE files_fileid_seq OWNER TO postgres;

--
-- Name: files_fileid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE files_fileid_seq OWNED BY files.fileid;


--
-- Name: inboxes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE inboxes (
    inboxid integer NOT NULL,
    receiverid integer,
    inmessage character varying(3000),
    insubject character varying(50),
    senderid integer
);


ALTER TABLE inboxes OWNER TO postgres;

--
-- Name: inboxes_inboxid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE inboxes_inboxid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE inboxes_inboxid_seq OWNER TO postgres;

--
-- Name: inboxes_inboxid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE inboxes_inboxid_seq OWNED BY inboxes.inboxid;


--
-- Name: likes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE likes (
    likeid integer NOT NULL,
    likedaccountid integer,
    likeraccountid integer,
    likecount integer
);


ALTER TABLE likes OWNER TO postgres;

--
-- Name: likes_likeid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE likes_likeid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE likes_likeid_seq OWNER TO postgres;

--
-- Name: likes_likeid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE likes_likeid_seq OWNED BY likes.likeid;


--
-- Name: nclynationaccordions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE nclynationaccordions (
    id integer NOT NULL,
    nclynationid integer NOT NULL,
    latestcontent1 character varying(100),
    latestevents character varying(3000),
    portfoliobibil character varying(3000),
    portfolioskills character varying(3000),
    platforms character varying(3000)
);


ALTER TABLE nclynationaccordions OWNER TO postgres;

--
-- Name: nclynationaccordions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE nclynationaccordions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE nclynationaccordions_id_seq OWNER TO postgres;

--
-- Name: nclynationaccordions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE nclynationaccordions_id_seq OWNED BY nclynationaccordions.id;


--
-- Name: nclynations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE nclynations (
    nclynationid integer NOT NULL,
    nclynationname character varying(30),
    accountid integer
);


ALTER TABLE nclynations OWNER TO postgres;

--
-- Name: nclynations_nclynationid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE nclynations_nclynationid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE nclynations_nclynationid_seq OWNER TO postgres;

--
-- Name: nclynations_nclynationid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE nclynations_nclynationid_seq OWNED BY nclynations.nclynationid;


--
-- Name: outboxes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE outboxes (
    outboxid integer NOT NULL,
    senderid integer,
    outmessage character varying(3000),
    outsubject character varying(50),
    recipientid integer
);


ALTER TABLE outboxes OWNER TO postgres;

--
-- Name: outboxes_outboxid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE outboxes_outboxid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE outboxes_outboxid_seq OWNER TO postgres;

--
-- Name: outboxes_outboxid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE outboxes_outboxid_seq OWNED BY outboxes.outboxid;


--
-- Name: posts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE posts (
    postid integer NOT NULL,
    accountid integer,
    postcontent character varying(250),
    postdate timestamp without time zone,
    sender character varying(25)
);


ALTER TABLE posts OWNER TO postgres;

--
-- Name: posts_postid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE posts_postid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE posts_postid_seq OWNER TO postgres;

--
-- Name: posts_postid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE posts_postid_seq OWNED BY posts.postid;


--
-- Name: talents; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE talents (
    id integer NOT NULL,
    talent1 character varying(3000)
);


ALTER TABLE talents OWNER TO postgres;

--
-- Name: talents_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE talents_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE talents_id_seq OWNER TO postgres;

--
-- Name: talents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE talents_id_seq OWNED BY talents.id;


--
-- Name: usersfolloweds; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE usersfolloweds (
    id integer NOT NULL,
    followerid integer,
    followedid integer,
    followedname character varying(25)
);


ALTER TABLE usersfolloweds OWNER TO postgres;

--
-- Name: usersfolloweds_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE usersfolloweds_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE usersfolloweds_id_seq OWNER TO postgres;

--
-- Name: usersfolloweds_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE usersfolloweds_id_seq OWNED BY usersfolloweds.id;


--
-- Name: accounts id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY accounts ALTER COLUMN id SET DEFAULT nextval('accounts_id_seq'::regclass);


--
-- Name: acctalents talentid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY acctalents ALTER COLUMN talentid SET DEFAULT nextval('acctalents_talentid_seq'::regclass);


--
-- Name: comments commentid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY comments ALTER COLUMN commentid SET DEFAULT nextval('comments_commentid_seq'::regclass);


--
-- Name: details detailsid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY details ALTER COLUMN detailsid SET DEFAULT nextval('details_detailsid_seq'::regclass);


--
-- Name: embededs embededid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY embededs ALTER COLUMN embededid SET DEFAULT nextval('embededs_embededid_seq'::regclass);


--
-- Name: files fileid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY files ALTER COLUMN fileid SET DEFAULT nextval('files_fileid_seq'::regclass);


--
-- Name: inboxes inboxid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY inboxes ALTER COLUMN inboxid SET DEFAULT nextval('inboxes_inboxid_seq'::regclass);


--
-- Name: likes likeid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY likes ALTER COLUMN likeid SET DEFAULT nextval('likes_likeid_seq'::regclass);


--
-- Name: nclynationaccordions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY nclynationaccordions ALTER COLUMN id SET DEFAULT nextval('nclynationaccordions_id_seq'::regclass);


--
-- Name: nclynations nclynationid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY nclynations ALTER COLUMN nclynationid SET DEFAULT nextval('nclynations_nclynationid_seq'::regclass);


--
-- Name: outboxes outboxid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY outboxes ALTER COLUMN outboxid SET DEFAULT nextval('outboxes_outboxid_seq'::regclass);


--
-- Name: posts postid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY posts ALTER COLUMN postid SET DEFAULT nextval('posts_postid_seq'::regclass);


--
-- Name: talents id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY talents ALTER COLUMN id SET DEFAULT nextval('talents_id_seq'::regclass);


--
-- Name: usersfolloweds id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY usersfolloweds ALTER COLUMN id SET DEFAULT nextval('usersfolloweds_id_seq'::regclass);


--
-- Data for Name: accounts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY accounts (id, username, accountrole, accpassword, useremail, remember, likes) FROM stdin;
\.
COPY accounts (id, username, accountrole, accpassword, useremail, remember, likes) FROM '$$PATH$$/2922.dat';

--
-- Data for Name: acctalents; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY acctalents (talentid, talentname, nclynationid) FROM stdin;
\.
COPY acctalents (talentid, talentname, nclynationid) FROM '$$PATH$$/2924.dat';

--
-- Data for Name: comments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY comments (commentid, accountid, comment1, sender, senderid, datesent) FROM stdin;
\.
COPY comments (commentid, accountid, comment1, sender, senderid, datesent) FROM '$$PATH$$/2926.dat';

--
-- Data for Name: details; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY details (hook, accountid, nclynation, detailsid) FROM stdin;
\.
COPY details (hook, accountid, nclynation, detailsid) FROM '$$PATH$$/2928.dat';

--
-- Data for Name: embededs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY embededs (nclynationid, src, framefrom, frametype, embededid) FROM stdin;
\.
COPY embededs (nclynationid, src, framefrom, frametype, embededid) FROM '$$PATH$$/2930.dat';

--
-- Data for Name: files; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY files (filename, contenttype, content, filetype, accountid, fileid) FROM stdin;
\.
COPY files (filename, contenttype, content, filetype, accountid, fileid) FROM '$$PATH$$/2932.dat';

--
-- Data for Name: inboxes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY inboxes (inboxid, receiverid, inmessage, insubject, senderid) FROM stdin;
\.
COPY inboxes (inboxid, receiverid, inmessage, insubject, senderid) FROM '$$PATH$$/2934.dat';

--
-- Data for Name: likes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY likes (likeid, likedaccountid, likeraccountid, likecount) FROM stdin;
\.
COPY likes (likeid, likedaccountid, likeraccountid, likecount) FROM '$$PATH$$/2936.dat';

--
-- Data for Name: nclynationaccordions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY nclynationaccordions (id, nclynationid, latestcontent1, latestevents, portfoliobibil, portfolioskills, platforms) FROM stdin;
\.
COPY nclynationaccordions (id, nclynationid, latestcontent1, latestevents, portfoliobibil, portfolioskills, platforms) FROM '$$PATH$$/2938.dat';

--
-- Data for Name: nclynations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY nclynations (nclynationid, nclynationname, accountid) FROM stdin;
\.
COPY nclynations (nclynationid, nclynationname, accountid) FROM '$$PATH$$/2940.dat';

--
-- Data for Name: outboxes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY outboxes (outboxid, senderid, outmessage, outsubject, recipientid) FROM stdin;
\.
COPY outboxes (outboxid, senderid, outmessage, outsubject, recipientid) FROM '$$PATH$$/2942.dat';

--
-- Data for Name: posts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY posts (postid, accountid, postcontent, postdate, sender) FROM stdin;
\.
COPY posts (postid, accountid, postcontent, postdate, sender) FROM '$$PATH$$/2944.dat';

--
-- Data for Name: talents; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY talents (id, talent1) FROM stdin;
\.
COPY talents (id, talent1) FROM '$$PATH$$/2946.dat';

--
-- Data for Name: usersfolloweds; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY usersfolloweds (id, followerid, followedid, followedname) FROM stdin;
\.
COPY usersfolloweds (id, followerid, followedid, followedname) FROM '$$PATH$$/2948.dat';

--
-- Name: accounts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('accounts_id_seq', 12, true);


--
-- Name: acctalents_talentid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('acctalents_talentid_seq', 1, false);


--
-- Name: comments_commentid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('comments_commentid_seq', 7, true);


--
-- Name: details_detailsid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('details_detailsid_seq', 1, true);


--
-- Name: embededs_embededid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('embededs_embededid_seq', 1, false);


--
-- Name: files_fileid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('files_fileid_seq', 1, true);


--
-- Name: inboxes_inboxid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('inboxes_inboxid_seq', 1, false);


--
-- Name: likes_likeid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('likes_likeid_seq', 1, false);


--
-- Name: nclynationaccordions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('nclynationaccordions_id_seq', 1, false);


--
-- Name: nclynations_nclynationid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('nclynations_nclynationid_seq', 7, true);


--
-- Name: outboxes_outboxid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('outboxes_outboxid_seq', 1, false);


--
-- Name: posts_postid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('posts_postid_seq', 1, true);


--
-- Name: talents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('talents_id_seq', 3, true);


--
-- Name: usersfolloweds_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('usersfolloweds_id_seq', 1, false);


--
-- Name: accounts account_id_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY accounts
    ADD CONSTRAINT account_id_pk PRIMARY KEY (id);


--
-- Name: acctalents acctalents_id_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY acctalents
    ADD CONSTRAINT acctalents_id_pk PRIMARY KEY (talentid);


--
-- Name: comments comment_id_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY comments
    ADD CONSTRAINT comment_id_pk PRIMARY KEY (commentid);


--
-- Name: details details_id_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY details
    ADD CONSTRAINT details_id_pk PRIMARY KEY (detailsid);


--
-- Name: files files_id_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY files
    ADD CONSTRAINT files_id_pk PRIMARY KEY (fileid);


--
-- Name: inboxes inboxes_id_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY inboxes
    ADD CONSTRAINT inboxes_id_pk PRIMARY KEY (inboxid);


--
-- Name: likes likes_id_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY likes
    ADD CONSTRAINT likes_id_pk PRIMARY KEY (likeid);


--
-- Name: nclynations nclynations_id_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY nclynations
    ADD CONSTRAINT nclynations_id_pk PRIMARY KEY (nclynationid);


--
-- Name: outboxes outboxes_id_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY outboxes
    ADD CONSTRAINT outboxes_id_pk PRIMARY KEY (outboxid);


--
-- Name: posts posts_id_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY posts
    ADD CONSTRAINT posts_id_pk PRIMARY KEY (postid);


--
-- Name: talents talent_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY talents
    ADD CONSTRAINT talent_pk PRIMARY KEY (id);


--
-- Name: comments comment_accountid_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY comments
    ADD CONSTRAINT comment_accountid_fk FOREIGN KEY (accountid) REFERENCES accounts(id);


--
-- Name: details detail_accountid_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY details
    ADD CONSTRAINT detail_accountid_fk FOREIGN KEY (accountid) REFERENCES accounts(id);


--
-- Name: files file_accountid_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY files
    ADD CONSTRAINT file_accountid_fk FOREIGN KEY (accountid) REFERENCES accounts(id);


--
-- Name: inboxes inbox_receiverid_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY inboxes
    ADD CONSTRAINT inbox_receiverid_fk FOREIGN KEY (receiverid) REFERENCES accounts(id);


--
-- Name: likes like_accountid_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY likes
    ADD CONSTRAINT like_accountid_fk FOREIGN KEY (likedaccountid) REFERENCES accounts(id);


--
-- Name: likes liker_accountid_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY likes
    ADD CONSTRAINT liker_accountid_fk FOREIGN KEY (likeraccountid) REFERENCES accounts(id);


--
-- Name: nclynations nclynation_accountid_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY nclynations
    ADD CONSTRAINT nclynation_accountid_fk FOREIGN KEY (accountid) REFERENCES accounts(id);


--
-- Name: outboxes outbox_senderid_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY outboxes
    ADD CONSTRAINT outbox_senderid_fk FOREIGN KEY (senderid) REFERENCES accounts(id);


--
-- Name: posts post_accountid_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY posts
    ADD CONSTRAINT post_accountid_fk FOREIGN KEY (accountid) REFERENCES accounts(id);


--
-- PostgreSQL database dump complete
--

